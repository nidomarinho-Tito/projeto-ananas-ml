# Relatório Final de Modelagem - Cultivares de Abacaxi

Este relatório foi gerado automaticamente a partir do último treinamento do modelo.

## 1. Informações do Modelo
- **Algoritmo:** `RandomForestClassifier`
- **Versão:** `1.0.0`
- **Limitação Científica:** Métricas sobre dados simulados; não validado em campo.

## 2. Divisão do Conjunto de Dados
- **Treino:** 840 amostras
- **Validação:** 180 amostras
- **Teste:** 180 amostras

## 3. Desempenho (Conjunto de Teste Isolado)
- **Acurácia (Accuracy):** 93.89%
- **F1-Score (Macro):** 93.88%
- **Área Sob a Curva ROC (ROC-AUC OVR):** 99.58%

## 4. Interpretação e rastreabilidade
- **Escolha do modelo:** hiperparâmetros fixados previamente, sem ajuste automático.
- **Probabilidades:** não calibradas; não representam confiança em dados de campo.
- **Matriz de confusão:** utiliza os mesmos índices do conjunto de teste isolado.
- **Base:** dados sintéticos com parâmetros manuais; consulte `data/proveniencia_base.md`.

## 5. Classes Suportadas pela API
BRS_Imperial, BRS_Vitoria, MD2_Gold, Perola, Smooth_Cayenne
