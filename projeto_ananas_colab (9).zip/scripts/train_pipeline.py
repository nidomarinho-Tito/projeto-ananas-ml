"""
Fase 1: Preparacao, Treinamento e Serializacao do Pipeline Preditivo (Offline)
Projeto: Classificacao Morfoagronomica de Cultivares de Abacaxi (Ananas comosus L. Merril)
"""

import json
from pathlib import Path
import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.pipeline import Pipeline
from sklearn.compose import ColumnTransformer
from sklearn.impute import SimpleImputer
from sklearn.preprocessing import StandardScaler, OneHotEncoder
from sklearn.ensemble import RandomForestClassifier
from sklearn.metrics import accuracy_score, f1_score, roc_auc_score, classification_report, log_loss, confusion_matrix
import joblib

BASE_DIR = Path(__file__).resolve().parent.parent
DATA_PATH = BASE_DIR / "data" / "ananas_comosus_cultivares.csv"
MODEL_PATH = BASE_DIR / "models" / "pipeline_ananas_v1.joblib"
METRICS_PATH = BASE_DIR / "models" / "metrics_report.json"
TEST_INDICES_PATH = BASE_DIR / "models" / "test_indices.json"

NUMERIC_FEATURES = [
    "massa_fruto_g",
    "comprimento_fruto_cm",
    "diametro_fruto_cm",
    "diametro_cilindro_mm",
    "brix_sst",
    "acidez_titulavel_pct",
    "firmeza_polpa_n",
]

CATEGORICAL_FEATURES = [
    "cor_polpa",
    "presenca_espinhos",
    "formato_fruto",
]

TARGET_COL = "cultivar"


def build_pipeline() -> Pipeline:
    numeric_transformer = Pipeline(
        steps=[
            ("imputer", SimpleImputer(strategy="median")),
            ("scaler", StandardScaler()),
        ]
    )

    categorical_transformer = Pipeline(
        steps=[
            ("imputer", SimpleImputer(strategy="most_frequent")),
            ("encoder", OneHotEncoder(handle_unknown="ignore", sparse_output=False)),
        ]
    )

    preprocessor = ColumnTransformer(
        transformers=[
            ("num", numeric_transformer, NUMERIC_FEATURES),
            ("cat", categorical_transformer, CATEGORICAL_FEATURES),
        ],
        remainder="drop",
    )

    classifier = RandomForestClassifier(
        n_estimators=250,
        max_depth=12,
        min_samples_split=4,
        min_samples_leaf=2,
        class_weight="balanced",
        random_state=42,
        n_jobs=-1,
    )

    return Pipeline(
        steps=[
            ("preprocessor", preprocessor),
            ("classifier", classifier),
        ]
    )


def main() -> None:
    if not DATA_PATH.is_file():
        raise FileNotFoundError(f"Base não encontrada: {DATA_PATH}")
    df = pd.read_csv(DATA_PATH)
    required = set(NUMERIC_FEATURES + CATEGORICAL_FEATURES + [TARGET_COL])
    missing = required.difference(df.columns)
    if missing:
        raise ValueError(f"Colunas ausentes na base: {sorted(missing)}")
    X = df[NUMERIC_FEATURES + CATEGORICAL_FEATURES]
    y = df[TARGET_COL]

    X_train, X_temp, y_train, y_temp = train_test_split(
        X, y, test_size=0.30, stratify=y, random_state=42
    )
    X_val, X_test, y_val, y_test = train_test_split(
        X_temp, y_temp, test_size=0.50, stratify=y_temp, random_state=42
    )

    pipeline = build_pipeline()
    pipeline.fit(X_train, y_train)
    # O conjunto de teste permanece isolado até a avaliação final.

    val_preds = pipeline.predict(X_val)
    val_probs = pipeline.predict_proba(X_val)
    test_preds = pipeline.predict(X_test)
    test_probs = pipeline.predict_proba(X_test)

    # A validação é apenas diagnóstica: hiperparâmetros fixados previamente,
    # sem busca automática nem seleção baseada no conjunto de teste.
    # Probabilidades não calibradas não são garantia de confiança em campo.
    metrics = {
        "model_version": "1.0.0",
        "dataset_origin": "synthetic_demonstration",
        "scientific_limitation": "Métricas sobre dados simulados; não validado em campo.",
        "algorithm": "RandomForestClassifier",
        "dataset_splits": {
            "train_samples": len(X_train),
            "validation_samples": len(X_val),
            "test_samples": len(X_test),
        },
        "validation_metrics": {
            "accuracy": round(float(accuracy_score(y_val, val_preds)), 4),
            "f1_macro": round(float(f1_score(y_val, val_preds, average="macro")), 4),
            "roc_auc_ovr": round(float(roc_auc_score(y_val, val_probs, multi_class="ovr", average="macro")), 4),
        },
        "test_metrics": {
            "accuracy": round(float(accuracy_score(y_test, test_preds)), 4),
            "f1_macro": round(float(f1_score(y_test, test_preds, average="macro")), 4),
            "roc_auc_ovr": round(float(roc_auc_score(y_test, test_probs, multi_class="ovr", average="macro")), 4),
        },
        "classes": list(pipeline.classes_),
        "hyperparameter_selection": "Valores fixados previamente; não houve tuning por validação.",
        "probability_interpretation": "Estimativas não calibradas em dados sintéticos; não representam confiança em campo.",
        "validation_log_loss": round(float(log_loss(y_val, val_probs, labels=pipeline.classes_)), 4),
        "test_confusion_matrix": confusion_matrix(y_test, test_preds, labels=pipeline.classes_).tolist(),
    }

    MODEL_PATH.parent.mkdir(parents=True, exist_ok=True)
    # Índices do teste isolado: reutilizados sem refazer o split ou excluir nulos.
    TEST_INDICES_PATH.write_text(json.dumps([int(i) for i in X_test.index]), encoding="utf-8")
    joblib.dump(pipeline, MODEL_PATH)
    with open(METRICS_PATH, "w", encoding="utf-8") as f:
        json.dump(metrics, f, indent=4, ensure_ascii=False)

    print("=== RELATORIO DE TREINAMENTO E SERIALIZACAO ===")
    print(json.dumps(metrics, indent=2, ensure_ascii=False))
    print("\nRelatorio Detalhado (Conjunto de Teste):")
    print(classification_report(y_test, test_preds))


if __name__ == "__main__":
    main()
