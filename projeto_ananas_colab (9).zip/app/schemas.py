"""
Fase 4: Modelagem e Validacao Estrita de Dados com Pydantic.
"""

from typing import Dict, Literal
from pydantic import BaseModel, Field, ConfigDict, field_validator


class AmostraAbacaxiInput(BaseModel):
    @field_validator("massa_fruto_g", "comprimento_fruto_cm", "diametro_fruto_cm",
                     "diametro_cilindro_mm", "brix_sst", "acidez_titulavel_pct",
                     "firmeza_polpa_n", mode="before")
    @classmethod
    def exigir_numero_json(cls, value):
        if isinstance(value, bool) or not isinstance(value, (int, float)):
            raise ValueError("O campo deve ser numérico, sem conversão de texto")
        return value

    massa_fruto_g: float = Field(..., ge=400.0, le=4500.0, description="Massa do fruto sem coroa (g)")
    comprimento_fruto_cm: float = Field(..., ge=8.0, le=35.0, description="Comprimento do fruto (cm)")
    diametro_fruto_cm: float = Field(..., ge=6.0, le=22.0, description="Diametro equatorial do fruto (cm)")
    diametro_cilindro_mm: float = Field(..., gt=5.0, le=50.0, description="Diametro do cilindro central (mm)")
    brix_sst: float = Field(..., ge=8.0, le=25.0, description="Solidos Soluveis Totais (graus Brix)")
    acidez_titulavel_pct: float = Field(..., gt=0.10, le=2.00, description="Acidez Titulavel (% acido citrico)")
    firmeza_polpa_n: float = Field(..., ge=5.0, le=40.0, description="Firmeza da polpa (Newtons)")
    cor_polpa: Literal["branca", "amarelo_palido", "amarela", "amarelo_ouro"] = Field(...)
    presenca_espinhos: Literal["presente", "ausente"] = Field(...)
    formato_fruto: Literal["conico", "cilindrico"] = Field(...)

    model_config = ConfigDict(
        extra="forbid",
        json_schema_extra={
            "example": {
                "massa_fruto_g": 1480.0,
                "comprimento_fruto_cm": 16.2,
                "diametro_fruto_cm": 12.1,
                "diametro_cilindro_mm": 18.5,
                "brix_sst": 17.6,
                "acidez_titulavel_pct": 0.52,
                "firmeza_polpa_n": 20.5,
                "cor_polpa": "amarelo_ouro",
                "presenca_espinhos": "ausente",
                "formato_fruto": "cilindrico",
            }
        }
    )


class PredicaoCultivarOutput(BaseModel):
    cultivar_predita: str
    confianca_predicao: float = Field(..., ge=0.0, le=1.0)
    probabilidades_classes: Dict[str, float]
    ratio_brix_acidez: float
    aptidao_recomendada: str
    resistencia_fusariose: str
    versao_modelo: str = Field(default="1.0.0")


class HealthCheckOutput(BaseModel):
    status: str
    model_loaded: bool = Field(description="Indica se o modelo está carregado")
    artifact_path: str
    supported_cultivars: list[str]
