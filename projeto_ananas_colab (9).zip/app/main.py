"""
Fase 2 e Fase 3: Ponto de Entrada da Aplicacao e Gerenciamento de Ciclo de Vida (main.py).
"""

from contextlib import asynccontextmanager
from pathlib import Path
import logging
from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import RedirectResponse
from app.routers import router
from app.services import AnanasClassifierService

logging.basicConfig(level=logging.INFO, format="%(asctime)s | %(levelname)s | %(message)s")
logger = logging.getLogger("ananas_api")

BASE_DIR = Path(__file__).resolve().parent.parent
MODEL_PATH = BASE_DIR / "models" / "pipeline_ananas_v1.joblib"


@asynccontextmanager
async def lifespan(app: FastAPI):
    logger.info("Carregando artefato preditivo em memoria RAM...")
    ml_service = AnanasClassifierService(model_path=MODEL_PATH)
    ml_service.load_model()
    app.state.ml_service = ml_service
    try:
        yield
    finally:
        logger.info("Encerrando serviço e liberando memória...")
        ml_service.unload_model()


app = FastAPI(
    title="API de Classificacao Morfoagronomica de Abacaxi (Ananas comosus)",
    version="1.0.0",
    lifespan=lifespan,
)


# A documentação Swagger, servida na mesma origem, não depende de CORS.
import os
origins = [v.strip() for v in os.getenv("ANANAS_CORS_ORIGINS", "").split(",") if v.strip()]
if origins:
    app.add_middleware(
        CORSMiddleware,
        allow_origins=origins,
        allow_credentials=False,
        allow_methods=["GET", "POST"],
        allow_headers=["Content-Type"],
    )

app.include_router(router)

# Redirecionamento da raiz para a documentação interativa.
@app.get("/", include_in_schema=False)
async def root_redirect():
    """Redireciona acessos à raiz da API direto para a documentação interativa."""
    return RedirectResponse(url="/docs")
