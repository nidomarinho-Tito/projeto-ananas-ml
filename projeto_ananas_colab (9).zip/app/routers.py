"""
Fase 2 e Fase 5: Implementacao de Rotas e Tratamento de Excecoes HTTP (routers.py).
"""

import logging
from fastapi import APIRouter, HTTPException, Request, status
from app.schemas import AmostraAbacaxiInput, PredicaoCultivarOutput, HealthCheckOutput
from app.services import AnanasClassifierService, DomainValidationError

logger = logging.getLogger(__name__)
router = APIRouter()


def _get_ml_service(request: Request) -> AnanasClassifierService:
    service: AnanasClassifierService | None = getattr(request.app.state, "ml_service", None)
    if service is None or not service.is_ready:
        raise HTTPException(
            status_code=status.HTTP_503_SERVICE_UNAVAILABLE,
            detail="Modelo preditivo indisponivel em memoria RAM.",
        )
    return service


@router.get(
    "/health",
    response_model=HealthCheckOutput,
    status_code=status.HTTP_200_OK,
    tags=["Monitoramento"],
)
async def health_check(request: Request) -> HealthCheckOutput:
    service: AnanasClassifierService | None = getattr(request.app.state, "ml_service", None)
    is_loaded = bool(service and service.is_ready)
    return HealthCheckOutput(
        status="healthy" if is_loaded else "degraded",
        model_loaded=is_loaded,
        artifact_path="models/pipeline_ananas_v1.joblib",
        supported_cultivars=service.get_classes() if is_loaded else [],
    )


@router.post(
    "/v1/predict",
    response_model=PredicaoCultivarOutput,
    status_code=status.HTTP_200_OK,
    tags=["Inferencia Agronomica"],
)
@router.post(
    "/predict",
    response_model=PredicaoCultivarOutput,
    status_code=status.HTTP_200_OK,
    tags=["Inferencia Agronomica"],
)
async def predict_cultivar(payload: AmostraAbacaxiInput, request: Request) -> PredicaoCultivarOutput:
    service = _get_ml_service(request)
    try:
        return service.predict(payload)
    except DomainValidationError as exc:
        raise HTTPException(status_code=status.HTTP_400_BAD_REQUEST, detail=str(exc)) from exc
    except RuntimeError as exc:
        raise HTTPException(status_code=503, detail="Modelo preditivo indisponível.") from exc
    except Exception as exc:
        logger.exception("Erro inesperado durante a inferência")
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="Falha interna durante o processamento da inferência.",
        ) from exc
