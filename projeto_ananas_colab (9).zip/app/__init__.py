"""API de classificação de cultivares de abacaxi."""
