"""
Fase 2: Camada de Servico e Regras de Negocio Agronomicas (services.py).
"""

from pathlib import Path
from typing import Dict
import pandas as pd
import joblib

from app.schemas import AmostraAbacaxiInput, PredicaoCultivarOutput

CATALOGO_AGRONOMICO: Dict[str, Dict[str, str]] = {
    "Perola": {
        "aptidao": "Consumo In Natura (Mercado Interno - Preferencia Nacional)",
        "fusariose": "Suscetivel (requer manejo fitossanitario rigoroso)",
    },
    "Smooth_Cayenne": {
        "aptidao": "Dupla Aptidao (Processamento Industrial de Suco/Calda e Mesa)",
        "fusariose": "Suscetivel",
    },
    "BRS_Imperial": {
        "aptidao": "Mesa Premium e Exportacao (Elevado Ratio SST/AT e polpa amarelo-ouro)",
        "fusariose": "Resistente a Fusarium guttiforme",
    },
    "BRS_Vitoria": {
        "aptidao": "Mesa In Natura e Processamento Leve (Folhas sem espinhos)",
        "fusariose": "Resistente a Fusarium guttiforme",
    },
    "MD2_Gold": {
        "aptidao": "Exportacao In Natura (Alta firmeza de polpa e vida util pos-colheita)",
        "fusariose": "Moderadamente Suscetivel",
    },
}


class DomainValidationError(ValueError):
    pass


class AnanasClassifierService:
    def __init__(self, model_path: Path) -> None:
        self.model_path = model_path
        self.pipeline = None
        self.versao_modelo = "1.0.0"

    def load_model(self) -> None:
        if not self.model_path.exists():
            raise FileNotFoundError(f"Artefato nao encontrado em {self.model_path}")
        # Carregar somente artefatos gerados pelo próprio projeto (joblib usa pickle).
        self.pipeline = joblib.load(self.model_path)

    def unload_model(self) -> None:
        self.pipeline = None

    @property
    def is_ready(self) -> bool:
        return self.pipeline is not None

    def get_classes(self) -> list[str]:
        if not self.is_ready:
            return []
        return [str(c) for c in self.pipeline.classes_]

    def _validate_biophysical_consistency(self, payload: AmostraAbacaxiInput) -> None:
        diametro_fruto_mm = payload.diametro_fruto_cm * 10.0
        # Regra didática de plausibilidade, NÃO um limiar agronômico oficial.
        if payload.diametro_cilindro_mm >= (diametro_fruto_mm * 0.65):
            raise DomainValidationError(
                f"Inconsistencia morfometrica: diametro do cilindro central ({payload.diametro_cilindro_mm} mm) "
                f"excede 65% do diametro total do fruto ({diametro_fruto_mm:.1f} mm)."
            )

    def predict(self, payload: AmostraAbacaxiInput) -> PredicaoCultivarOutput:
        if not self.is_ready:
            raise RuntimeError("O pipeline preditivo nao esta carregado em memoria.")

        self._validate_biophysical_consistency(payload)

        input_df = pd.DataFrame([payload.model_dump()])
        probs = self.pipeline.predict_proba(input_df)[0]
        classes = self.pipeline.classes_

        prob_dict = {str(cls): round(float(prob), 4) for cls, prob in zip(classes, probs)}
        best_idx = int(probs.argmax())
        cultivar_predita = str(classes[best_idx])
        confianca = round(float(probs[best_idx]), 4)

        ratio_sst_at = round(payload.brix_sst / payload.acidez_titulavel_pct, 2)
        info_catalogo = CATALOGO_AGRONOMICO.get(
            cultivar_predita, {"aptidao": "Uso Geral", "fusariose": "Nao especificado"}
        )

        return PredicaoCultivarOutput(
            cultivar_predita=cultivar_predita,
            confianca_predicao=confianca,
            probabilidades_classes=prob_dict,
            ratio_brix_acidez=ratio_sst_at,
            aptidao_recomendada=info_catalogo["aptidao"],
            resistencia_fusariose=info_catalogo["fusariose"],
            versao_modelo=self.versao_modelo,
        )
