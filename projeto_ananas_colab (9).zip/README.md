# Projeto Ananas — classificação morfoagronômica (demonstração)

API FastAPI para classificar cinco cultivares de abacaxi com um pipeline scikit-learn treinado em **dados sintéticos**. Não é um diagnóstico agronômico validado.

## Estrutura
- `data/`: base sintética, proveniência e previsões em lote.
- `scripts/train_pipeline.py`: preparação, treinamento e avaliação com divisão estratificada 70/15/15.
- `models/`: pipeline, métricas, índices do teste isolado e matriz de confusão.
- `app/schemas.py`: validação Pydantic.
- `app/services.py`: inferência e catálogo ilustrativo.
- `app/routers.py`: endpoints e tratamento de erros.
- `app/main.py`: carregamento via lifespan, CORS configurável e redirecionamento da raiz.
- `tests/test_api.py`: testes HTTP e validação.

## Execução local
```bash
python -m pip install -r requirements.txt
python scripts/train_pipeline.py
python -m unittest discover -s tests -v
python -m uvicorn app.main:app --host 127.0.0.1 --port 8000
```
Acesse `http://127.0.0.1:8000/docs`. No Colab, execute as células em ordem; o proxy do Colab permite abrir o Swagger no navegador.

## Exemplo de requisição
`POST /v1/predict` (também disponível em `/predict`):
```json
{"massa_fruto_g":1480,"comprimento_fruto_cm":16.2,"diametro_fruto_cm":12.1,"diametro_cilindro_mm":18.5,"brix_sst":17.6,"acidez_titulavel_pct":0.52,"firmeza_polpa_n":20.5,"cor_polpa":"amarelo_ouro","presenca_espinhos":"ausente","formato_fruto":"cilindrico"}
```
`GET /health`: 200 com status do modelo. `POST`: 200 sucesso, 422 entrada inválida, 400 inconsistência morfométrica didática, 503 modelo indisponível e 500 erro inesperado. A regra de 65% é apenas heurística de demonstração, sem validação agronômica.

## Avaliação e limites
Hiperparâmetros fixados antes do teste; a validação é diagnóstica, não uma busca de parâmetros. O conjunto de teste isolado tem índices persistidos em `models/test_indices.json`, reutilizados na matriz de confusão sem excluir ausentes. As probabilidades não são calibradas e não expressam confiança em campo. Métricas são válidas apenas para a distribuição simulada. Consulte `data/proveniencia_base.md`.

## Segurança e ambiente
Somente carregue `.joblib` produzido por fonte confiável. CORS fica desativado por padrão; para permitir um frontend específico, configure `ANANAS_CORS_ORIGINS=https://exemplo.com` antes de iniciar a API. Versões de dependências têm faixas compatíveis para Colab; o ambiente deve ser registrado em entregas reprodutíveis.

## Entrega
O ZIP final inclui código, dados sintéticos, testes, métricas, gráficos e relatório, gerados após todas as etapas. Acrescente links de vídeo e repositório somente após a publicação, sem usar links fictícios.
