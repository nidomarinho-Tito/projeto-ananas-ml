# Proveniência da base Ananas

- Tipo: base inteiramente sintética para demonstração de software.
- Classes: Perola, Smooth_Cayenne, BRS_Imperial, BRS_Vitoria, MD2_Gold.
- Variáveis numéricas: massa, comprimento, diâmetros, sólidos solúveis, acidez e firmeza; unidades nos nomes das colunas.
- Variáveis categóricas: cor da polpa, espinhos e formato.
- Parâmetros de distribuição: médias, desvios e probabilidades definidos manualmente no notebook; **não derivados de medições oficiais**.
- Método: gerador NumPy com semente 42, 240 amostras por classe, truncamento de valores e ausências artificiais de aproximadamente 2% em quatro colunas com semente 123.
- Referências de contexto: https://www.embrapa.br/mandioca-e-fruticultura ; https://www.embrapa.br/busca-de-publicacoes ; https://www.gov.br/agricultura/pt-br/assuntos/insumos-agricolas/sementes-e-mudas/registro-nacional-de-cultivares-rnc
- Limitação: as fontes são pontos de consulta; não foi verificada uma tabela primária que sustente cada parâmetro numérico ou cada afirmação do catálogo.
- Uso: apenas ensino, testes de integração e demonstração. Não validado em campo.
