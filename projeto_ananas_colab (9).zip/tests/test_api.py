import unittest
from unittest.mock import patch
from fastapi.testclient import TestClient
from app.main import app

VALIDO = {
    "massa_fruto_g": 1480.0, "comprimento_fruto_cm": 16.2,
    "diametro_fruto_cm": 12.1, "diametro_cilindro_mm": 18.5,
    "brix_sst": 17.6, "acidez_titulavel_pct": 0.52,
    "firmeza_polpa_n": 20.5, "cor_polpa": "amarelo_ouro",
    "presenca_espinhos": "ausente", "formato_fruto": "cilindrico",
}

class TestAPI(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.manager = TestClient(app)
        cls.client = cls.manager.__enter__()

    @classmethod
    def tearDownClass(cls):
        cls.manager.__exit__(None, None, None)

    def test_health(self):
        r = self.client.get("/health")
        self.assertEqual(r.status_code, 200)
        self.assertTrue(r.json()["model_loaded"])

    def test_predict_and_probabilities(self):
        r = self.client.post("/v1/predict", json=VALIDO)
        self.assertEqual(r.status_code, 200)
        data = r.json()
        self.assertIn(data["cultivar_predita"], data["probabilidades_classes"])
        self.assertAlmostEqual(sum(data["probabilidades_classes"].values()), 1, delta=0.001)
        self.assertAlmostEqual(data["confianca_predicao"], max(data["probabilidades_classes"].values()))

    def test_predict_alias(self):
        self.assertEqual(self.client.post("/predict", json=VALIDO).status_code, 200)

    def test_missing_required_field(self):
        invalid = dict(VALIDO)
        del invalid["massa_fruto_g"]
        self.assertEqual(self.client.post("/v1/predict", json=invalid).status_code, 422)

    def test_unknown_category(self):
        self.assertEqual(self.client.post("/v1/predict", json=dict(VALIDO, cor_polpa="roxa")).status_code, 422)

    def test_invalid_numeric_type(self):
        self.assertEqual(self.client.post("/v1/predict", json=dict(VALIDO, brix_sst="17.6")).status_code, 422)

    def test_numeric_bounds(self):
        for field, value in [("brix_sst", 25.1), ("massa_fruto_g", 399), ("acidez_titulavel_pct", 0.1)]:
            with self.subTest(field=field):
                self.assertEqual(self.client.post("/v1/predict", json=dict(VALIDO, **{field: value})).status_code, 422)

    def test_extra_field(self):
        self.assertEqual(self.client.post("/v1/predict", json=dict(VALIDO, origem="teste")).status_code, 422)

    def test_domain_consistency(self):
        invalid = dict(VALIDO, diametro_fruto_cm=6.5, diametro_cilindro_mm=48.0)
        self.assertEqual(self.client.post("/v1/predict", json=invalid).status_code, 400)

    def test_unavailable_service(self):
        service = app.state.ml_service
        with patch.object(service, "pipeline", None):
            self.assertEqual(self.client.post("/v1/predict", json=VALIDO).status_code, 503)

    def test_root_redirect(self):
        self.assertEqual(self.client.get("/", follow_redirects=False).status_code, 307)

if __name__ == "__main__":
    unittest.main()
